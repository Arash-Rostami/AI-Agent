export const allowFrameEmbedding = (req, res, next) => {

    const allowedOrigins = [
        'http://localhost:8000/',
        'http://127.0.0.1:8000/',
        'https://team.persolco.com'
    ];

    if (
        req.headers.referer &&
        allowedOrigins.some(origin => req.headers.referer.startsWith(origin))
    ) {
        res.removeHeader('X-Frame-Options');
        res.setHeader('Content-Security-Policy', "frame-ancestors *");
    }

    next();
};
